const authPanel = document.getElementById('auth-panel');
const dashboard = document.getElementById('dashboard');
const loginForm = document.getElementById('login-form');
const addCurrentForm = document.getElementById('add-current-form');
const addRemoteForm = document.getElementById('add-remote-form');
const searchForm = document.getElementById('search-form');
const deviceList = document.getElementById('device-list');
const logoutBtn = document.getElementById('logout-btn');
const userName = document.getElementById('user-name');
const userEmail = document.getElementById('user-email');
const deviceCount = document.getElementById('device-count');
const trackedCount = document.getElementById('tracked-count');

let currentUser = null;
let devices = [];

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...options
  });
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error || 'Request failed');
  }
  return data;
}

function renderDashboard() {
  authPanel.classList.add('hidden');
  dashboard.classList.remove('hidden');
  userName.textContent = currentUser.name;
  userEmail.textContent = currentUser.email;
  deviceCount.textContent = devices.length;
  trackedCount.textContent = devices.filter((device) => device.status === 'tracked').length;
}

function renderDevices(items) {
  if (!items.length) {
    deviceList.innerHTML = '<div class="panel">No devices registered yet.</div>';
    return;
  }

  deviceList.innerHTML = items
    .map((device) => {
      const security = device.security || {};
      const lockBadge = security.lockScreen ? '<span class="badge">Locked</span>' : '<span class="badge warn">Unlocked</span>';
      return `
        <article class="device-card">
          <div class="device-header">
            <div>
              <h3>${device.name}</h3>
              <p class="small">${device.type} • ${device.id}</p>
            </div>
            ${lockBadge}
          </div>
          <div class="device-meta">
            <span>Serial: ${device.serial}</span>
            <span>IMEI: ${device.imei}</span>
            <span>Battery: ${device.battery}%</span>
            <span>Last seen: ${device.lastSeen}</span>
          </div>
          <p class="small">Location: ${device.location}</p>
          <div class="actions">
            <button data-action="track" data-id="${device.id}">Track device</button>
            <button data-action="lock" data-id="${device.id}">Lock features</button>
            <button data-action="unlock" data-id="${device.id}">Unlock</button>
            <button data-action="logs" data-id="${device.id}">View BIOS logs</button>
          </div>
          <div class="small">
            Airplane mode: ${security.airplaneMode ? 'Locked' : 'Open'} • Settings: ${security.settingsLocked ? 'Locked' : 'Open'} • Menu: ${security.menuLocked ? 'Locked' : 'Open'}
          </div>
          <ul class="log-list">
            ${device.trackingHistory.slice(0, 2).map((entry) => `<li>${entry.time} — ${entry.note}</li>`).join('')}
          </ul>
        </article>
      `;
    })
    .join('');
}

async function loadDevices() {
  devices = await api('/api/devices');
  renderDevices(devices);
  renderDashboard();
}

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const payload = {
    email: document.getElementById('email').value,
    password: document.getElementById('password').value
  };

  try {
    const response = await api('/api/auth/login', { method: 'POST', body: JSON.stringify(payload) });
    currentUser = response.user;
    await loadDevices();
  } catch (error) {
    alert(error.message);
  }
});

Array.from(document.querySelectorAll('.social-btn')).forEach((button) => {
  button.addEventListener('click', async () => {
    try {
      const response = await api('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ provider: button.dataset.provider })
      });
      currentUser = response.user;
      await loadDevices();
    } catch (error) {
      alert(error.message);
    }
  });
});

addCurrentForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const created = await api('/api/devices', {
      method: 'POST',
      body: JSON.stringify({ mode: 'current' })
    });
    devices.unshift(created);
    renderDevices(devices);
    renderDashboard();
  } catch (error) {
    alert(error.message);
  }
});

addRemoteForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const payload = {
      mode: 'remote',
      deviceId: document.getElementById('remote-id').value,
      password: document.getElementById('remote-password').value,
      name: document.getElementById('remote-name').value,
      serial: document.getElementById('remote-serial').value,
      imei: document.getElementById('remote-imei').value,
      type: 'Phone'
    };

    const created = await api('/api/devices', { method: 'POST', body: JSON.stringify(payload) });
    devices.unshift(created);
    renderDevices(devices);
    renderDashboard();
    addRemoteForm.reset();
  } catch (error) {
    alert(error.message);
  }
});

searchForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const query = document.getElementById('search-query').value;
  const response = await api('/api/search', { method: 'POST', body: JSON.stringify({ query }) });
  renderDevices(response);
});

deviceList.addEventListener('click', async (event) => {
  const actionButton = event.target.closest('button[data-action]');
  if (!actionButton) {
    return;
  }

  const action = actionButton.dataset.action;
  const deviceId = actionButton.dataset.id;

  try {
    if (action === 'track') {
      const updated = await api(`/api/devices/${deviceId}/track`, { method: 'POST', body: JSON.stringify({ location: 'Secure tracking ping' }) });
      devices = devices.map((device) => (device.id === deviceId ? updated : device));
      renderDevices(devices);
    } else if (action === 'lock') {
      const updated = await api(`/api/devices/${deviceId}/lock`, { method: 'POST' });
      devices = devices.map((device) => (device.id === deviceId ? updated : device));
      renderDevices(devices);
    } else if (action === 'unlock') {
      const updated = await api(`/api/devices/${deviceId}/unlock`, { method: 'POST' });
      devices = devices.map((device) => (device.id === deviceId ? updated : device));
      renderDevices(devices);
    } else if (action === 'logs') {
      const logs = await api(`/api/devices/${deviceId}/logs`);
      const found = devices.find((device) => device.id === deviceId);
      if (found) {
        alert(logs.map((entry) => `${entry.time} — ${entry.event}`).join('\n'));
      }
    }
  } catch (error) {
    alert(error.message);
  }
});

logoutBtn.addEventListener('click', () => {
  currentUser = null;
  authPanel.classList.remove('hidden');
  dashboard.classList.add('hidden');
});
