# Find My Device

A polished web experience for registering devices, tracking them using hardware identifiers, and enforcing lock-screen protections.

## Features
- Secure login screen with email and social login buttons
- Dashboard for current and remote device registration
- Search by device name, serial number, or IMEI
- Device-specific tracking APIs and BIOS-style safety logs
- Docker and Docker Compose support

## Run locally
- npm install
- npm start

## Run with Docker
- docker compose up --build
