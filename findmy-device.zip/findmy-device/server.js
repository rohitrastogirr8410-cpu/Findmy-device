const express = require('express');
const path = require('path');
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const users = [
  {
    id: 'user-1001',
    name: 'Ava Chen',
    email: 'ava@example.com',
    password: 'demo123',
    provider: 'Email'
  }
];

const devices = [
  {
    id: 'device-1001',
    ownerId: 'user-1001',
    name: 'Ava Laptop',
    type: 'Laptop',
    serial: 'SN-9001',
    imei: '356000000000001',
    status: 'tracked',
    battery: 82,
    location: 'Seattle, WA',
    lastSeen: '2 min ago',
    security: {
      lockScreen: true,
      airplaneMode: true,
      settingsLocked: true,
      menuLocked: true
    },
    trackingHistory: [
      { time: '2026-07-22 08:03', note: 'Location pinged from Seattle' },
      { time: '2026-07-22 07:41', note: 'Security lock enabled after suspicious access' }
    ],
    biosLogs: [
      { time: '2026-07-22 08:12', event: 'Boot integrity verified' },
      { time: '2026-07-22 07:49', event: 'Hard-reset protection marker attached' }
    ]
  }
];

function findUser(email, password) {
  return users.find((user) => user.email === email && user.password === password);
}

function findDevice(id) {
  return devices.find((device) => device.id === id);
}

function addDevice(device) {
  devices.unshift(device);
  return device;
}

function createDevicePayload(payload) {
  return {
    id: payload.deviceId || `device-${Date.now()}`,
    ownerId: 'user-1001',
    name: payload.name || 'New Device',
    type: payload.type || 'Phone',
    serial: payload.serial || 'SN-NEW',
    imei: payload.imei || 'IMEI-NEW',
    status: payload.mode === 'current' ? 'active' : 'pending',
    battery: 100,
    location: payload.mode === 'current' ? 'Current login location' : 'Pending verification',
    lastSeen: 'Just added',
    security: {
      lockScreen: payload.mode === 'current',
      airplaneMode: payload.mode === 'current',
      settingsLocked: payload.mode === 'current',
      menuLocked: payload.mode === 'current'
    },
    trackingHistory: [
      { time: new Date().toLocaleString(), note: 'Device added to account' }
    ],
    biosLogs: [
      { time: new Date().toLocaleString(), event: 'Device registration logged in BIOS-safe audit trail' }
    ]
  };
}

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', devices: devices.length });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password, provider } = req.body;
  if (provider && provider !== 'Email') {
    const user = users[0];
    return res.json({ user: { ...user, provider } });
  }

  const user = findUser(email, password);
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  res.json({ user });
});

app.get('/api/devices', (req, res) => {
  res.json(devices);
});

app.post('/api/devices', (req, res) => {
  const { mode, deviceId, password, name, type, serial, imei } = req.body;

  if (mode === 'remote') {
    if (!deviceId || !password) {
      return res.status(400).json({ error: 'Device ID and password are required for remote device setup.' });
    }
    if (password !== 'secure123') {
      return res.status(401).json({ error: 'Remote device authentication failed.' });
    }
  }

  const payload = createDevicePayload({ mode, deviceId, name, type, serial, imei });
  const device = addDevice(payload);
  res.status(201).json(device);
});

app.get('/api/devices/:id', (req, res) => {
  const device = findDevice(req.params.id);
  if (!device) {
    return res.status(404).json({ error: 'Device not found' });
  }
  res.json(device);
});

app.post('/api/devices/:id/track', (req, res) => {
  const device = findDevice(req.params.id);
  if (!device) {
    return res.status(404).json({ error: 'Device not found' });
  }

  device.status = 'tracked';
  device.location = req.body.location || 'Tracked by secure network';
  device.lastSeen = 'Just pinged';
  device.trackingHistory.unshift({
    time: new Date().toLocaleString(),
    note: `Tracking refreshed from ${device.location}`
  });
  device.biosLogs.unshift({
    time: new Date().toLocaleString(),
    event: 'Tracking audit entry recorded in BIOS-safe ledger'
  });

  res.json(device);
});

app.post('/api/devices/:id/lock', (req, res) => {
  const device = findDevice(req.params.id);
  if (!device) {
    return res.status(404).json({ error: 'Device not found' });
  }

  device.security.lockScreen = true;
  device.security.airplaneMode = true;
  device.security.settingsLocked = true;
  device.security.menuLocked = true;
  device.trackingHistory.unshift({
    time: new Date().toLocaleString(),
    note: 'Lock screen security enforced and menu access blocked'
  });

  res.json(device);
});

app.post('/api/devices/:id/unlock', (req, res) => {
  const device = findDevice(req.params.id);
  if (!device) {
    return res.status(404).json({ error: 'Device not found' });
  }

  device.security.lockScreen = false;
  device.security.airplaneMode = false;
  device.security.settingsLocked = false;
  device.security.menuLocked = false;
  device.trackingHistory.unshift({
    time: new Date().toLocaleString(),
    note: 'Device unlocked and restrictions lifted'
  });

  res.json(device);
});

app.get('/api/devices/:id/logs', (req, res) => {
  const device = findDevice(req.params.id);
  if (!device) {
    return res.status(404).json({ error: 'Device not found' });
  }
  res.json(device.biosLogs);
});

app.post('/api/search', (req, res) => {
  const query = (req.body.query || '').toLowerCase();
  const result = devices.filter((device) => [
    device.name,
    device.serial,
    device.imei,
    device.id
  ].some((value) => value.toLowerCase().includes(query)));

  res.json(result);
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

if (require.main === module) {
  app.listen(port, () => {
    console.log(`Find My Device app running on http://localhost:${port}`);
  });
}

module.exports = { app };
