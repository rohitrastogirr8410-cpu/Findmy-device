const test = require('node:test');
const assert = require('node:assert/strict');
const { app } = require('../server');
const express = require('express');

const server = app.listen(0);

function request(path, options = {}) {
  const port = server.address().port;
  return fetch(`http://127.0.0.1:${port}${path}`, options);
}

test('health endpoint responds', async () => {
  const response = await request('/api/health');
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.status, 'ok');
});

test('login accepts demo credentials', async () => {
  const response = await request('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'ava@example.com', password: 'demo123' })
  });
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.user.email, 'ava@example.com');
});

test('device registration works with remote credentials', async () => {
  const response = await request('/api/devices', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mode: 'remote', deviceId: 'device-2001', password: 'secure123', name: 'Tablet', serial: 'SN-9002', imei: '356000000000002' })
  });
  assert.equal(response.status, 201);
  const body = await response.json();
  assert.equal(body.name, 'Tablet');
});

test('search endpoint returns matching device', async () => {
  const response = await request('/api/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query: 'SN-9002' })
  });
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.ok(body.some((device) => device.serial === 'SN-9002'));
});

test.after(async () => {
  await new Promise((resolve) => server.close(resolve));
});
